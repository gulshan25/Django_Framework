from django.contrib import admin
from StudentApp.models import Student

# Register your models here.
admin.site.register(Student)