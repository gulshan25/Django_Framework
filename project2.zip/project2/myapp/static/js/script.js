function Welcome()
{
    alert ('I love my Mother');
}